import View.Menus.LoginMenu;

public class Main {
    public static void main(String[] args) {
        new LoginMenu().run();
    }
}
