package Model.Users;

public class RestaurantAdmin extends User {
    public RestaurantAdmin(String username, String password) {
        super(username, password);
    }
}
