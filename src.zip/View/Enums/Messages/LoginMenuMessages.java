package View.Enums.Messages;

public enum LoginMenuMessages {
    INVALID_USERNAME_FORMAT,
    USERNAME_EXIST,
    USERNAME_NOT_EXIST,
    INVALID_PASSWORD_FORMAT,
    WEAK_PASSWORD,
    WRONG_PASSWORD,
    SUCCESS,

}
