package View.Enums.Messages;

public enum MainMenuMessages {
    INVALID_MENU_NAME,
    ACCESS_DENIED,
    SUCCESS,
}
