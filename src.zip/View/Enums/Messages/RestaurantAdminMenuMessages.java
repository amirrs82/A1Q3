package View.Enums.Messages;

public enum RestaurantAdminMenuMessages {
    INVALID_AMOUNT,
    INVALID_CATEGORY,
    INVALID_NAME,
    FOOD_EXIST,
    FOOD_NOT_EXIST,
    SUCCESS,
}
